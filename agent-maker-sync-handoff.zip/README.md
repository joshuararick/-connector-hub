# Agent Maker → Ai Army Sync Handoff

This package is a concrete sync handoff bundle for the Codex workspace/local repo at:

`C:\Users\joshu\OneDrive\Documents\Ai Army`

## What this bundle does

It gives Codex a repeatable, writable-safe sync workflow:

1. Verify the local repo state.
2. Import source files from `source_drop_here/`.
3. Preserve existing repo metadata.
4. Create/refresh project documentation.
5. Stage a clean Git commit when files are present.

## What is missing

The actual Agent Maker project source files were not accessible in this ChatGPT session. The only available uploaded artifact was `Sync Setup Assistance.txt`, included in `docs/`.

To complete a true source sync, put the exported Agent Maker project files into `source_drop_here/` before running the script, or replace this bundle with a real project `.zip` export.

## Run on Windows PowerShell

From inside this extracted bundle:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\sync-agent-maker.ps1 -TargetRepo "C:\Users\joshu\OneDrive\Documents\Ai Army"
```

Optional dry run:

```powershell
.\scripts\sync-agent-maker.ps1 -TargetRepo "C:\Users\joshu\OneDrive\Documents\Ai Army" -DryRun
```

## Expected output

- A verified Git repo at the target path.
- `docs/agent-maker-sync-status.md` in the repo.
- Any files placed in `source_drop_here/` copied into the repo.
- A Git commit named `Sync Agent Maker handoff` when changes exist.

## Notes

If Codex or the workspace is read-only, this cannot modify the target repo. Switch the workspace to writable and rerun.
