
# Agent Maker Sync Handoff

This package provides scripts and documentation to help synchronize the Agent Maker project into the local `Ai Army` repository. Because the ChatGPT project cannot be fetched directly and the workspace is read-only, you must perform the following steps manually:

1. Obtain the Agent Maker project source (zip export or project files) and place them into `source_drop_here`.
2. Make sure your Codex workspace is writable.
3. Run the sync script:

   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\scripts\sync-agent-maker.ps1 -TargetRepo "C:\Users\joshu\OneDrive\Documents\Ai Army"
   ```

4. Inspect the repository using `scripts\inspect-ai-army.ps1`.
5. Configure a remote and push the initial commit if needed.

See `docs/agent-maker-sync-status.md` for details on the current environment and obstacles.
