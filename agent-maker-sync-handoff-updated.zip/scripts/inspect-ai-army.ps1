
param(
    [string]$TargetRepo = "C:\Users\joshu\OneDrive\Documents\Ai Army"
)

Write-Host "== Inspect Ai Army Repo =="
if (!(Test-Path $TargetRepo)) {
    Write-Host "Target repo not found: $TargetRepo"
    exit 1
}

# Display directory structure
Get-ChildItem -Path $TargetRepo -Recurse | Format-List
