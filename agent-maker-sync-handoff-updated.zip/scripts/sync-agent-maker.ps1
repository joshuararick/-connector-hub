
param(
    [string]$TargetRepo = "C:\Users\joshu\OneDrive\Documents\Ai Army"
)

Write-Host "== Agent Maker Sync Script =="

# Ensure target directory exists
if (!(Test-Path $TargetRepo)) {
    Write-Host "Creating target repo directory: $TargetRepo"
    New-Item -ItemType Directory -Path $TargetRepo -Force | Out-Null
}

# Path to the local source files (the export from ChatGPT Projects)
$SourceDir = Join-Path -Path (Split-Path -Parent $MyInvocation.MyCommand.Path) -ChildPath '..\source_drop_here'

if (!(Test-Path $SourceDir)) {
    Write-Error "Source directory not found: $SourceDir"
    exit 1
}

# Copy files from source to target repo
Write-Host "Copying files from $SourceDir to $TargetRepo..."
Copy-Item -Path (Join-Path $SourceDir '*') -Destination $TargetRepo -Recurse -Force

Write-Host "Sync complete."
