
# Codex Sync Task: Agent Maker → Ai Army

This task prepares a local workspace for syncing the Agent Maker project into the empty repository located at `C:\Users\joshu\OneDrive\Documents\Ai Army`. Because the ChatGPT project URL is not directly accessible and the workspace is read-only by default, we provide a handoff package instead.

**You must perform these steps once the workspace is writable and the project source is available:**

1. Place the exported Agent Maker project files inside the `source_drop_here` directory of this package.
2. Open a PowerShell session and run the `scripts\sync-agent-maker.ps1` script:

   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\scripts\sync-agent-maker.ps1 -TargetRepo "C:\Users\joshu\OneDrive\Documents\Ai Army"
   ```

3. Verify that the files have been copied and the repository has been initialized. Use the `scripts\inspect-ai-army.ps1` script to inspect the contents.
4. Set up a Git remote if needed, commit the files, and push to your preferred remote (GitHub or other).

This task cannot run until the ChatGPT workspace is writable and the Agent Maker project source is provided.
